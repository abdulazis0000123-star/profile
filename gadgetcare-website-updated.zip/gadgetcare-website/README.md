# GadgetCare — Website Profil

Website landing page statis dengan tema hitam-merah, logo resmi GadgetCare, foto Abdul Azis, ikon media sosial, dan tombol booking.

## Tautan yang digunakan
- Booking: https://gadgetcare.web.id
- Threads: https://www.threads.com/@abd_ulaziys
- TikTok: https://www.tiktok.com/@abd_ulaziys
- Instagram: https://www.instagram.com/abd_ulaziys/

## Cara menjalankan
Buka `index.html` di browser.

## Cara mengunggah ke GitHub
1. Masuk ke https://github.com/new
2. Buat repository bernama `gadgetcare-website` (Public jika ingin memakai GitHub Pages).
3. Unggah file `index.html` dan `README.md` dari ZIP ini.
4. Buka Settings → Pages.
5. Pada Build and deployment, pilih `Deploy from a branch`, branch `main`, folder `/ (root)`, lalu Save.
6. Setelah selesai, website bisa dibuka pada URL GitHub Pages yang ditampilkan di halaman Pages.

## Menghubungkan domain sendiri
Untuk memakai `gadgetcare.web.id` sebagai domain situs ini, atur DNS dan Custom domain di GitHub Pages. Jika domain itu sudah digunakan oleh website GadgetCare yang aktif, jangan ubah DNS sebelum memastikan apakah ingin mengganti website yang sekarang.


## Aset gambar
Folder `assets/` berisi logo GadgetCare, foto Abdul Azis, dan ikon Threads, Instagram, serta TikTok yang digunakan oleh halaman.
